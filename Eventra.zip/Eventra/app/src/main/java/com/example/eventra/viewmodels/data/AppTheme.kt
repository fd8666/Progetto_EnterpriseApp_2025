package com.example.eventra.viewmodels.data

enum class AppTheme {
    LIGHT,
    DARK,
    SYSTEM
}