package com.example.eventra.screens

import android.annotation.SuppressLint
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.eventra.Visibilita
import com.example.eventra.viewmodels.EventiViewModel
import com.example.eventra.viewmodels.WishlistViewModel
import com.example.eventra.viewmodels.data.EventoData
import com.example.eventra.viewmodels.data.WishlistData
import kotlinx.coroutines.delay

val utenteId: Long = 1

@SuppressLint("RememberReturnType")
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun WishlistScreen() {
    val context = LocalContext.current

    val wishlistViewModel: WishlistViewModel = viewModel {
        WishlistViewModel(context.applicationContext as android.app.Application)
    }

    val eventiViewModel: EventiViewModel = viewModel {
        EventiViewModel(context.applicationContext as android.app.Application)
    }

    val wishlistsByVisibilita by wishlistViewModel.wishlistsByVisibilita.collectAsState()
    val wishlistCondivise by wishlistViewModel.wishlistCondivise.collectAsState()
    val eventi by eventiViewModel.eventi.collectAsState()
    val isLoading by wishlistViewModel.isLoading.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }

    // Carica i dati
    LaunchedEffect(Unit) {
        wishlistViewModel.getWishlistsByUtenteAndVisibilita(utenteId, Visibilita.PRIVATA)
        wishlistViewModel.getWishlistCondiviseConUtente(utenteId)
        eventiViewModel.getAllEventi()
    }

    // Calcola gli eventi delle wishlist private
    val eventiWishlistPrivate = remember(wishlistsByVisibilita, eventi) {
        val eventiIds = wishlistsByVisibilita?.flatMap { it.eventi }?.toSet() ?: emptySet()
        eventi?.filter { eventiIds.contains(it.id) } ?: emptyList()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(EventraColors.BackgroundGray)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            // Header Wishlist
            item {
                WishlistHeader()
            }

            // Tab Selector
            item {
                WishlistTabSelector(
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it },
                    privateCount = eventiWishlistPrivate.size,
                    sharedCount = wishlistCondivise?.size ?: 0, // Conta le wishlist, non gli eventi
                    showShareButton = eventiWishlistPrivate.isNotEmpty()
                )
            }

            // Content based on selected tab
            when (selectedTab) {
                0 -> {
                    // Tab Eventi Privati
                    if (eventiWishlistPrivate.isNotEmpty()) {
                        item {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(((eventiWishlistPrivate.size / 2 + eventiWishlistPrivate.size % 2) * 300).dp)
                                    .padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                userScrollEnabled = false
                            ) {
                                items(eventiWishlistPrivate) { evento ->
                                    WishlistEventCard(
                                        evento = evento,
                                        wishlistViewModel = wishlistViewModel,
                                        isInWishlistContext = true,
                                        onClick = { /* dettagli evento */ }
                                    )
                                }
                            }
                        }
                    } else {
                        item {
                            WishlistEmptyState(
                                title = "Nessun evento salvato",
                                subtitle = "Inizia ad aggiungere eventi alle tue wishlist!",
                                icon = Icons.Default.FavoriteBorder
                            )
                        }
                    }
                }
                1 -> {
                    // Tab Wishlist Condivise
                    item {
                        WishlistSectionHeader(
                            title = "Wishlist Condivise",
                            subtitle = "${wishlistCondivise?.size ?: 0} wishlist condivise con te"
                        )
                    }

                    if (!wishlistCondivise.isNullOrEmpty()) {
                        // Visualizza le wishlist come righe
                        items(wishlistCondivise!!) { wishlist ->
                            WishlistCondivisaCard(
                                wishlist = wishlist,
                                eventi = eventi ?: emptyList(),
                                wishlistViewModel = wishlistViewModel,
                                onClick = { /* Apri dettaglio wishlist */ }
                            )
                        }
                    } else {
                        item {
                            WishlistEmptyState(
                                title = "Nessuna wishlist condivisa",
                                subtitle = "Non hai ancora ricevuto wishlist condivise da altri utenti.",
                                icon = Icons.Default.Share
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(100.dp))
            }
        }

        // Loading indicator
        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                LoadingIndicator()
            }
        }
    }
}

@Composable
fun WishlistCondivisaCard(
    wishlist: WishlistData,
    eventi: List<EventoData>,
    wishlistViewModel: WishlistViewModel,
    onClick: () -> Unit
) {
    // Filtra gli eventi di questa wishlist
    val eventiWishlist = remember(wishlist.eventi, eventi) {
        eventi.filter { evento -> wishlist.eventi.contains(evento.id) }
    }

    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { isExpanded = !isExpanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header della wishlist
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Wishlist #${wishlist.id}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = EventraColors.TextDark
                        )

                        // Indica che è condivisa
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Wishlist condivisa",
                            tint = EventraColors.PrimaryOrange,
                            modifier = Modifier
                                .size(16.dp)
                                .padding(start = 8.dp)
                        )
                    }

                    Text(
                        text = "${eventiWishlist.size} eventi",
                        fontSize = 14.sp,
                        color = EventraColors.TextGray
                    )

                    Text(
                        text = "Creata il ${formatDate(wishlist.dataCreazione)}",
                        fontSize = 12.sp,
                        color = EventraColors.TextGray,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Comprimi" else "Espandi",
                    tint = EventraColors.TextGray,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Eventi della wishlist (visibili quando espansa)
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    Divider(
                        color = EventraColors.DividerGray,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    if (eventiWishlist.isNotEmpty()) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(((eventiWishlist.size / 2 + eventiWishlist.size % 2) * 300).dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            userScrollEnabled = false
                        ) {
                            items(eventiWishlist) { evento ->
                                // RIPRISTINATO: Usa il card normale con possibilità di rimuovere
                                WishlistEventCardCondivisa(
                                    evento = evento,
                                    wishlist = wishlist,
                                    wishlistViewModel = wishlistViewModel,
                                    onClick = { /* dettagli evento */ }
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EventBusy,
                                    contentDescription = null,
                                    tint = EventraColors.TextGray,
                                    modifier = Modifier.size(48.dp)
                                )

                                Text(
                                    text = "Nessun evento in questa wishlist",
                                    fontSize = 14.sp,
                                    color = EventraColors.TextGray,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Nuovo composable specifico per eventi nelle wishlist condivise
@Composable
fun WishlistEventCardCondivisa(
    evento: EventoData,
    wishlist: WishlistData,
    modifier: Modifier = Modifier,
    wishlistViewModel: WishlistViewModel,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    val heartScale by animateFloatAsState(
        targetValue = 1.2f, // Sempre visibile nelle wishlist condivise
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    val baseUrl = "http://10.0.2.2:8080/images/"
    val imageUrl = remember(evento.immagine) {
        if (!evento.immagine.isNullOrBlank()) {
            if (evento.immagine.startsWith("http")) evento.immagine
            else "$baseUrl${evento.immagine}"
        } else null
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .scale(scale)
            .clickable {
                isPressed = true
                onClick()
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                if (!imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(imageUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = evento.nome,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                EventraColors.DividerGray,
                                RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                // Cuore per rimuovere dalla wishlist condivisa
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .size(36.dp)
                        .background(
                            Color.White.copy(alpha = 0.9f),
                            shape = CircleShape
                        )
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) {
                            wishlistViewModel.removeEventoFromWishlist(
                                wishlistId = wishlist.id,
                                eventoId = evento.id,
                            ) {
                                // Ricarica le wishlist condivise dopo la rimozione
                                wishlistViewModel.getWishlistCondiviseConUtente(utenteId)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Rimuovi dalla mia copia",
                        tint = EventraColors.PrimaryOrange,
                        modifier = Modifier
                            .size(20.dp)
                            .scale(heartScale)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = evento.nome ?: "Evento",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = EventraColors.TextDark,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = evento.luogo,
                            fontSize = 11.sp,
                            color = EventraColors.TextGray,
                            modifier = Modifier.padding(start = 3.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = evento.dataOraEvento,
                            fontSize = 11.sp,
                            color = EventraColors.TextGray,
                            modifier = Modifier.padding(start = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column {
                    Text(
                        text = "${evento.postiDisponibili} posti",
                        fontSize = 13.sp,
                        color = EventraColors.PrimaryOrange,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "da €25",
                        fontSize = 14.sp,
                        color = EventraColors.TextDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            delay(100)
            isPressed = false
        }
    }
}

// Nuovo composable per eventi in sola lettura (senza possibilità di rimuovere)
@Composable
fun WishlistEventCardReadOnly(
    evento: EventoData,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    val baseUrl = "http://10.0.2.2:8080/images/"
    val imageUrl = remember(evento.immagine) {
        if (!evento.immagine.isNullOrBlank()) {
            if (evento.immagine.startsWith("http")) evento.immagine
            else "$baseUrl${evento.immagine}"
        } else null
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .scale(scale)
            .clickable {
                isPressed = true
                onClick()
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                if (!imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(imageUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = evento.nome,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                EventraColors.DividerGray,
                                RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                // RIMOSSO il cuore - le wishlist condivise sono in sola lettura
            }

            // Resto del card invariato
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = evento.nome ?: "Evento",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = EventraColors.TextDark,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = evento.luogo,
                            fontSize = 11.sp,
                            color = EventraColors.TextGray,
                            modifier = Modifier.padding(start = 3.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = evento.dataOraEvento,
                            fontSize = 11.sp,
                            color = EventraColors.TextGray,
                            modifier = Modifier.padding(start = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column {
                    Text(
                        text = "${evento.postiDisponibili} posti",
                        fontSize = 13.sp,
                        color = EventraColors.PrimaryOrange,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "da €25",
                        fontSize = 14.sp,
                        color = EventraColors.TextDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            delay(100)
            isPressed = false
        }
    }
}

// Funzione helper per formattare la data
private fun formatDate(dateString: String): String {
    return try {
        val parts = dateString.split("T")[0].split("-")
        "${parts[2]}/${parts[1]}/${parts[0]}"
    } catch (e: Exception) {
        dateString
    }
}

// Resto dei composable rimangono invariati...
@Composable
fun WishlistHeader() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        EventraColors.PrimaryOrange,
                        EventraColors.DarkOrange
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = "Wishlist",
                modifier = Modifier.size(64.dp),
                tint = Color.White
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Le Tue Wishlist",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Text(
                text = "I tuoi eventi preferiti in un posto",
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun WishlistTabSelector(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    privateCount: Int,
    sharedCount: Int,
    showShareButton: Boolean
) {
    var showShareDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val wishlistViewModel: WishlistViewModel = viewModel {
        WishlistViewModel(context.applicationContext as android.app.Application)
    }

    val isWishlistCondivisa by wishlistViewModel.isWishlistCondivisa.collectAsState()
    val condivisioneState by wishlistViewModel.condivisioneState.collectAsState()

    LaunchedEffect(showShareButton) {
        if (showShareButton) {
            val wishlistId = wishlistViewModel.getFirstPrivateWishlistId()
            if (wishlistId != null) {
                wishlistViewModel.verificaSeWishlistECondivisa(wishlistId)
            }
        }
    }

    LaunchedEffect(condivisioneState) {
        when (condivisioneState) {
            is WishlistViewModel.CondivisioneState.Success -> {
                wishlistViewModel.resetCondivisioneState()
            }
            is WishlistViewModel.CondivisioneState.Error -> {
                wishlistViewModel.resetCondivisioneState()
            }
            else -> {}
        }
    }

    Column(
        modifier = Modifier.padding(bottom = 24.dp) // Aggiunto padding bottom per più spazio
    ) {
        // Prima riga: Tab + Colonna dei pulsanti azione
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp), // Aumentato il padding verticale
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Tab Eventi
            WishlistTabItem(
                title = "Eventi",
                count = privateCount,
                isSelected = selectedTab == 0,
                onClick = { onTabSelected(0) },
                modifier = Modifier.weight(1f)
            )

            // Tab Condivise
            WishlistTabItem(
                title = "Condivise",
                count = sharedCount,
                isSelected = selectedTab == 1,
                onClick = { onTabSelected(1) },
                modifier = Modifier.weight(1f)
            )

            // Colonna dei pulsanti azione (Condividi + Elimina)
            if (showShareButton) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(88.dp), // Altezza fissa per matchare i tab (16dp padding top/bottom + contenuto)
                    verticalArrangement = if (isWishlistCondivisa) {
                        Arrangement.spacedBy(6.dp) // Se ci sono entrambi i pulsanti, distribuisci uniformemente
                    } else {
                        Arrangement.Center // Se c'è solo condividi, centrato
                    },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Tasto Condividi
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isWishlistCondivisa) 38.dp else 56.dp), // Altezza dinamica
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable { showShareDialog = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Condividi Wishlist",
                                tint = EventraColors.PrimaryOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // Tasto Elimina Condivisione (solo se condivisa)
                    if (isWishlistCondivisa) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp), // Stessa altezza del tasto condividi quando entrambi presenti
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable { showDeleteConfirmDialog = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Elimina Condivisioni",
                                    tint = Color.Red,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog per condivisione
    if (showShareDialog) {
        ShareDialog(
            onDismiss = { showShareDialog = false },
            onShare = { email ->
                val wishlistId = wishlistViewModel.getFirstPrivateWishlistId()
                if (wishlistId != null) {
                    wishlistViewModel.condividiWishlistConEmail(wishlistId, email)
                }
                showShareDialog = false
            }
        )
    }

    // Dialog per conferma eliminazione
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = {
                Text(
                    text = "Elimina Condivisioni",
                    fontWeight = FontWeight.Bold,
                    color = Color.Red
                )
            },
            text = {
                Text("Sei sicuro di voler rimuovere tutte le condivisioni di questa wishlist? Questa azione non può essere annullata.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val wishlistId = wishlistViewModel.getFirstPrivateWishlistId()
                        if (wishlistId != null) {
                            wishlistViewModel.rimuoviTutteCondivisioni(wishlistId) {
                                wishlistViewModel.getWishlistCondiviseConUtente(utenteId)
                            }
                        }
                        showDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Elimina", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Annulla")
                }
            }
        )
    }
}

@Composable
fun WishlistTabItem(
    title: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.02f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    Card(
        modifier = modifier
            .scale(scale)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                EventraColors.PrimaryOrange
            else
                EventraColors.CardWhite
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 8.dp else 2.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else EventraColors.PrimaryOrange
            )

            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = if (isSelected) Color.White else EventraColors.TextDark
            )
        }
    }
}

@Composable
fun WishlistSectionHeader(title: String, subtitle: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Text(
            text = title,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = EventraColors.TextDark
        )
        Text(
            text = subtitle,
            fontSize = 14.sp,
            color = EventraColors.TextGray
        )
    }
}

@Composable
fun WishlistEventCard(
    evento: EventoData,
    modifier: Modifier = Modifier,
    wishlistViewModel: WishlistViewModel,
    isInWishlistContext: Boolean = false,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    val isInWishlist = if (isInWishlistContext) {
        true
    } else {
        val wishlistsByVisibilita by wishlistViewModel.wishlistsByVisibilita.collectAsState()
        remember(wishlistsByVisibilita, evento.id) {
            wishlistsByVisibilita?.any { wishlist ->
                wishlist.eventi.contains(evento.id)
            } ?: false
        }
    }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    val heartScale by animateFloatAsState(
        targetValue = if (isInWishlist) 1.2f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
    )

    val baseUrl = "http://10.0.2.2:8080/images/"
    val imageUrl = remember(evento.immagine) {
        if (!evento.immagine.isNullOrBlank()) {
            if (evento.immagine.startsWith("http")) evento.immagine
            else "$baseUrl${evento.immagine}"
        } else null
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .scale(scale)
            .clickable {
                isPressed = true
                onClick()
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                if (!imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(imageUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = evento.nome,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                EventraColors.DividerGray,
                                RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .size(36.dp)
                        .background(
                            Color.White.copy(alpha = 0.9f),
                            shape = CircleShape
                        )
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) {
                            val wishlistId = wishlistViewModel.getFirstPrivateWishlistId()
                            if (wishlistId != null) {
                                if (isInWishlist) {
                                    wishlistViewModel.removeEventoFromWishlist(wishlistId, evento.id) {
                                        if (isInWishlistContext) {
                                            wishlistViewModel.getWishlistsByUtenteAndVisibilita(utenteId, Visibilita.PRIVATA)
                                            wishlistViewModel.getWishlistCondiviseConUtente(utenteId)
                                        } else {
                                            wishlistViewModel.getWishlistsByUtenteAndVisibilita(utenteId, Visibilita.PRIVATA)
                                        }
                                    }
                                } else {
                                    if (!isInWishlistContext) {
                                        wishlistViewModel.addEventoToWishlist(wishlistId, evento.id) {
                                            wishlistViewModel.getWishlistsByUtenteAndVisibilita(utenteId, Visibilita.PRIVATA)
                                        }
                                    }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isInWishlist) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isInWishlist) "Rimuovi dalla wishlist" else "Aggiungi alla wishlist",
                        tint = if (isInWishlist) EventraColors.PrimaryOrange else EventraColors.TextGray,
                        modifier = Modifier
                            .size(20.dp)
                            .scale(heartScale)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = evento.nome ?: "Evento",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = EventraColors.TextDark,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = evento.luogo,
                            fontSize = 11.sp,
                            color = EventraColors.TextGray,
                            modifier = Modifier.padding(start = 3.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = EventraColors.TextGray,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = evento.dataOraEvento,
                            fontSize = 11.sp,
                            color = EventraColors.TextGray,
                            modifier = Modifier.padding(start = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column {
                    Text(
                        text = "${evento.postiDisponibili} posti",
                        fontSize = 13.sp,
                        color = EventraColors.PrimaryOrange,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "da €25",
                        fontSize = 14.sp,
                        color = EventraColors.TextDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            delay(100)
            isPressed = false
        }
    }
}

@Composable
fun ShareDialog(
    onDismiss: () -> Unit,
    onShare: (String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Condividi via Email", fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email destinatario") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (email.isNotBlank()) onShare(email)
                },
                enabled = email.isNotBlank()
            ) {
                Text("Condividi")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annulla")
            }
        }
    )
}

@Composable
fun WishlistEmptyState(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EventraColors.CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = EventraColors.TextGray,
                modifier = Modifier.size(72.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = EventraColors.TextDark,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = subtitle,
                fontSize = 14.sp,
                color = EventraColors.TextGray,
                textAlign = TextAlign.Center
            )
        }
    }
}
