package com.example.eventra.viewmodels.data

data class ErrorData(
    val code: Int,
    val message: String
)
