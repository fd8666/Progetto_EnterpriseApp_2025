package com.example.eventra.viewmodels.data

data class WishlistCondivisaRequest(
    val id: Long? = null,
    val wishlistId: Long,
    val userId: Long
)

