package com.example.eventra.viewmodels.data

data class TagCategoriaData(
    val id: Long,
    val nome: String?,
    val descrizione: String?
)
