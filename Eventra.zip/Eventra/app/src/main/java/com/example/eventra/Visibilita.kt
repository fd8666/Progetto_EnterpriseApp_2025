package com.example.eventra

enum class Visibilita {
    CONDIVISA,
    PRIVATA
}
