package com.example.eventra.viewmodels.data

data class UtenteData(
    val id: Long,
    val nome: String,
    val cognome: String,
    val email: String,
    val numerotelefono: String
)